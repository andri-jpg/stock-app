<nav class="sb-topnav navbar navbar-expand-lg navbar-dark" style="background-color: #98FB98;">
<button class="btn btn-link btn-sm me-2" id="sidebarToggle">
    <i class="fas fa-bars" style="color: black;"></i>
</button>

    <a class="navbar-brand ms-2 ms-lg-4" href="index.php" style="color: black;">
        <img src="images/ico.png" alt="Nuansa Reklame Logo" class="me-2" width="30" height="30">
        Nuansa Reklame
    </a>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="logout.php" style="color: black;">
                    <i class="fas fa-sign-out-alt me-2" style="color: black;"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
</nav>
